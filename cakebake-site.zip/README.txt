CakeBake website (static, no build step)
Open index.html in a browser, or upload this whole folder to any web host.

index.html  page structure and SEO tags
styles.css  all styling (colors are CSS variables at the top)
app.js      pages, products, routing, contact settings (see CONFIG)
fx.js       Three.js background, 3D cake, cursor effects, scroll reveals
assets/     logo, cake photos, banner, video

To edit: products are in the P list in app.js; add WhatsApp/Instagram/email/phone in CONFIG in app.js.
The page loads Three.js and Google Fonts from the internet.
